
package com.albayan.app;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import org.json.*;

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DB_NAME = "albayan.db";
    public static final int DB_VERSION = 6;
    private final Context context;

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
        this.context = context;
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE meta(k TEXT PRIMARY KEY,v TEXT)");
        db.execSQL("INSERT INTO meta(k,v) VALUES('schema_version','6')");
        db.execSQL("CREATE TABLE users(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT UNIQUE,password_hash TEXT,full_name TEXT,role TEXT,active INTEGER DEFAULT 1)");
        db.execSQL("INSERT INTO users(username,password_hash,full_name,role) VALUES('admin','admin123','مدير النظام','مدير')");
        db.execSQL("CREATE TABLE items(id INTEGER PRIMARY KEY AUTOINCREMENT,code TEXT UNIQUE,barcode TEXT UNIQUE,name TEXT NOT NULL,category TEXT,unit TEXT,cost REAL DEFAULT 0,price REAL DEFAULT 0,min_qty REAL DEFAULT 0,qty REAL DEFAULT 0,active INTEGER DEFAULT 1)");
        db.execSQL("CREATE TABLE parties(id INTEGER PRIMARY KEY AUTOINCREMENT,kind TEXT,code TEXT UNIQUE,name TEXT NOT NULL,phone TEXT,address TEXT,balance REAL DEFAULT 0,active INTEGER DEFAULT 1)");
        db.execSQL("CREATE TABLE invoices(id INTEGER PRIMARY KEY AUTOINCREMENT,kind TEXT,invoice_no TEXT UNIQUE,party_id INTEGER,total REAL DEFAULT 0,paid REAL DEFAULT 0,remaining REAL DEFAULT 0,discount REAL DEFAULT 0,status TEXT DEFAULT 'نشطة',created_at TEXT DEFAULT CURRENT_TIMESTAMP)");
        db.execSQL("CREATE TABLE invoice_lines(id INTEGER PRIMARY KEY AUTOINCREMENT,invoice_id INTEGER,item_id INTEGER,qty REAL,returned_qty REAL DEFAULT 0,price REAL,cost REAL,total REAL)");
        db.execSQL("CREATE TABLE cash(id INTEGER PRIMARY KEY AUTOINCREMENT,kind TEXT,amount REAL,party_id INTEGER,note TEXT,ref_no TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP)");
        db.execSQL("CREATE TABLE returns(id INTEGER PRIMARY KEY AUTOINCREMENT,return_no TEXT UNIQUE,invoice_id INTEGER,item_id INTEGER,qty REAL,amount REAL,cost_amount REAL,created_at TEXT DEFAULT CURRENT_TIMESTAMP)");
        db.execSQL("CREATE INDEX idx_invoice_date ON invoices(created_at)");
        db.execSQL("CREATE INDEX idx_cash_date ON cash(created_at)");
        db.execSQL("CREATE INDEX idx_items_barcode ON items(barcode)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            safeExec(db, "ALTER TABLE invoice_lines ADD COLUMN returned_qty REAL DEFAULT 0");
            safeExec(db, "CREATE TABLE IF NOT EXISTS returns(id INTEGER PRIMARY KEY AUTOINCREMENT,return_no TEXT UNIQUE,invoice_id INTEGER,item_id INTEGER,qty REAL,amount REAL,cost_amount REAL,created_at TEXT DEFAULT CURRENT_TIMESTAMP)");
        }
        if (oldVersion < 3) {
            safeExec(db, "CREATE TABLE IF NOT EXISTS meta(k TEXT PRIMARY KEY,v TEXT)");
            safeExec(db, "CREATE INDEX IF NOT EXISTS idx_invoice_date ON invoices(created_at)");
            safeExec(db, "CREATE INDEX IF NOT EXISTS idx_cash_date ON cash(created_at)");
            safeExec(db, "CREATE INDEX IF NOT EXISTS idx_items_barcode ON items(barcode)");
        }
        if (oldVersion < 4) safeExec(db, "INSERT OR REPLACE INTO meta(k,v) VALUES('schema_version','4')");
        if (oldVersion < 5) safeExec(db, "INSERT OR REPLACE INTO meta(k,v) VALUES('schema_version','5')");
        if (oldVersion < 6) { safeExec(db, "ALTER TABLE invoices ADD COLUMN discount REAL DEFAULT 0"); safeExec(db, "INSERT OR REPLACE INTO meta(k,v) VALUES('schema_version','6')"); }
    }

    private void safeExec(SQLiteDatabase db, String sql) {
        try { db.execSQL(sql); } catch (Exception ignored) {}
    }

    public long addItem(String code,String barcode,String name,String category,String unit,double cost,double price,double minQty) {
        SQLiteDatabase db=getWritableDatabase(); ContentValues v=new ContentValues();
        v.put("code",code); if(!barcode.trim().isEmpty())v.put("barcode",barcode); v.put("name",name);v.put("category",category);v.put("unit",unit);v.put("cost",cost);v.put("price",price);v.put("min_qty",minQty);
        return db.insertOrThrow("items",null,v);
    }

    public long addParty(String kind,String code,String name,String phone,String address) {
        SQLiteDatabase db=getWritableDatabase(); ContentValues v=new ContentValues();
        v.put("kind",kind);v.put("code",code);v.put("name",name);v.put("phone",phone);v.put("address",address);
        return db.insertOrThrow("parties",null,v);
    }

    public JSONArray items() throws JSONException {
        JSONArray a=new JSONArray(); SQLiteDatabase db=getReadableDatabase();
        try(Cursor c=db.rawQuery("SELECT id,code,barcode,name,unit,cost,price,min_qty,qty FROM items WHERE active=1 ORDER BY name",null)){
            while(c.moveToNext()){JSONObject o=new JSONObject();o.put("id",c.getLong(0));o.put("code",c.getString(1));o.put("barcode",c.getString(2));o.put("name",c.getString(3));o.put("unit",c.getString(4));o.put("cost",c.getDouble(5));o.put("price",c.getDouble(6));o.put("min_qty",c.getDouble(7));o.put("qty",c.getDouble(8));a.put(o);}
        } return a;
    }

    public JSONArray parties(String kind) throws JSONException {
        JSONArray a=new JSONArray(); SQLiteDatabase db=getReadableDatabase();
        String sql="SELECT id,kind,code,name,phone,address,balance FROM parties WHERE active=1"+(kind==null?"":" AND kind=?")+" ORDER BY name";
        String[] args=kind==null?null:new String[]{kind};
        try(Cursor c=db.rawQuery(sql,args)){
            while(c.moveToNext()){JSONObject o=new JSONObject();o.put("id",c.getLong(0));o.put("kind",c.getString(1));o.put("code",c.getString(2));o.put("name",c.getString(3));o.put("phone",c.getString(4));o.put("address",c.getString(5));o.put("balance",c.getDouble(6));a.put(o);}
        } return a;
    }

    public long saveInvoice(String kind,long partyId,long itemId,double qty,double price,double paid) {
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try{
            double stock=0,cost=0;
            try(Cursor c=db.rawQuery("SELECT qty,cost FROM items WHERE id=?",new String[]{String.valueOf(itemId)})){
                if(!c.moveToFirst()) throw new IllegalArgumentException("الصنف غير موجود");
                stock=c.getDouble(0);cost=c.getDouble(1);
            }
            if(kind.equals("بيع") && qty>stock) throw new IllegalArgumentException("المخزون غير كافٍ");
            double total=qty*price; if(paid<0||paid>total) throw new IllegalArgumentException("المدفوع غير صحيح");
            double remaining=total-paid;
            String no=(kind.equals("بيع")?"S-":"P-")+new SimpleDateFormat("yyyyMMddHHmmss",Locale.US).format(new Date());

            ContentValues h=new ContentValues();h.put("kind",kind);h.put("invoice_no",no);if(partyId>0)h.put("party_id",partyId);h.put("total",total);h.put("paid",paid);h.put("remaining",remaining);
            long iid=db.insertOrThrow("invoices",null,h);
            ContentValues l=new ContentValues();l.put("invoice_id",iid);l.put("item_id",itemId);l.put("qty",qty);l.put("price",price);l.put("cost",cost);l.put("total",total);db.insertOrThrow("invoice_lines",null,l);
            db.execSQL("UPDATE items SET qty=qty+? WHERE id=?",new Object[]{kind.equals("بيع")?-qty:qty,itemId});
            if(partyId>0 && remaining!=0) db.execSQL("UPDATE parties SET balance=balance+? WHERE id=?",new Object[]{kind.equals("بيع")?remaining:-remaining,partyId});
            if(paid>0){
                ContentValues cv=new ContentValues();cv.put("kind",kind.equals("بيع")?"قبض":"صرف");cv.put("amount",paid);if(partyId>0)cv.put("party_id",partyId);cv.put("note","دفعة فاتورة "+kind);cv.put("ref_no",no);db.insert("cash",null,cv);
            }
            db.setTransactionSuccessful(); return iid;
        } finally {db.endTransaction();}
    }



    public long saveInvoiceMulti(String kind,long partyId,JSONArray lines,double paid,double discount) throws JSONException {
        if(lines==null || lines.length()==0) throw new IllegalArgumentException("الفاتورة فارغة");
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try{
            double gross=0;
            for(int i=0;i<lines.length();i++){
                JSONObject ln=lines.getJSONObject(i);
                double qty=ln.getDouble("qty"), price=ln.getDouble("price");
                if(qty<=0 || price<0) throw new IllegalArgumentException("كمية أو سعر غير صحيح");
                gross += qty*price;
            }
            if(discount<0 || discount>gross) throw new IllegalArgumentException("الخصم غير صحيح");
            double total=gross-discount;
            if(paid<0 || paid>total) throw new IllegalArgumentException("المدفوع غير صحيح");

            if(kind.equals("بيع")){
                HashMap<Long,Double> needed=new HashMap<>();
                for(int i=0;i<lines.length();i++){
                    JSONObject ln=lines.getJSONObject(i);
                    long itemId=ln.getLong("item_id");
                    needed.put(itemId,needed.getOrDefault(itemId,0.0)+ln.getDouble("qty"));
                }
                for(Map.Entry<Long,Double> e:needed.entrySet()){
                    try(Cursor c=db.rawQuery("SELECT qty FROM items WHERE id=?",new String[]{String.valueOf(e.getKey())})){
                        if(!c.moveToFirst()) throw new IllegalArgumentException("الصنف غير موجود");
                        if(e.getValue()>c.getDouble(0)) throw new IllegalArgumentException("المخزون غير كافٍ لأحد الأصناف");
                    }
                }
            }

            double remaining=total-paid;
            String no=(kind.equals("بيع")?"S-":"P-")+new SimpleDateFormat("yyyyMMddHHmmssSSS",Locale.US).format(new Date());
            ContentValues h=new ContentValues();
            h.put("kind",kind);h.put("invoice_no",no);if(partyId>0)h.put("party_id",partyId);
            h.put("total",total);h.put("paid",paid);h.put("remaining",remaining);h.put("discount",discount);
            long iid=db.insertOrThrow("invoices",null,h);

            for(int i=0;i<lines.length();i++){
                JSONObject ln=lines.getJSONObject(i);
                long itemId=ln.getLong("item_id");
                double qty=ln.getDouble("qty"),price=ln.getDouble("price"),cost=0;
                try(Cursor c=db.rawQuery("SELECT cost FROM items WHERE id=?",new String[]{String.valueOf(itemId)})){if(c.moveToFirst())cost=c.getDouble(0);}
                ContentValues l=new ContentValues();
                l.put("invoice_id",iid);l.put("item_id",itemId);l.put("qty",qty);l.put("price",price);l.put("cost",cost);l.put("total",qty*price);
                db.insertOrThrow("invoice_lines",null,l);
                db.execSQL("UPDATE items SET qty=qty+? WHERE id=?",new Object[]{kind.equals("بيع")?-qty:qty,itemId});
            }

            if(partyId>0 && remaining!=0)
                db.execSQL("UPDATE parties SET balance=balance+? WHERE id=?",new Object[]{kind.equals("بيع")?remaining:-remaining,partyId});

            if(paid>0){
                ContentValues cv=new ContentValues();
                cv.put("kind",kind.equals("بيع")?"قبض":"صرف");cv.put("amount",paid);
                if(partyId>0)cv.put("party_id",partyId);
                cv.put("note","دفعة فاتورة "+kind);cv.put("ref_no",no);
                db.insert("cash",null,cv);
            }
            db.setTransactionSuccessful();return iid;
        } finally {db.endTransaction();}
    }

    public JSONObject invoiceDetails(long invoiceId) throws JSONException {
        SQLiteDatabase db=getReadableDatabase();
        JSONObject out=new JSONObject();
        try(Cursor c=db.rawQuery("SELECT i.invoice_no,i.kind,COALESCE(p.name,'نقدي'),i.total,i.paid,i.remaining,COALESCE(i.discount,0),i.created_at FROM invoices i LEFT JOIN parties p ON p.id=i.party_id WHERE i.id=?",new String[]{String.valueOf(invoiceId)})){
            if(!c.moveToFirst())throw new IllegalArgumentException("الفاتورة غير موجودة");
            out.put("no",c.getString(0));out.put("kind",c.getString(1));out.put("party",c.getString(2));
            out.put("total",c.getDouble(3));out.put("paid",c.getDouble(4));out.put("remaining",c.getDouble(5));out.put("discount",c.getDouble(6));out.put("date",c.getString(7));
        }
        JSONArray lines=new JSONArray();
        try(Cursor c=db.rawQuery("SELECT it.name,l.qty,l.price,l.total FROM invoice_lines l JOIN items it ON it.id=l.item_id WHERE l.invoice_id=?",new String[]{String.valueOf(invoiceId)})){
            while(c.moveToNext()){JSONObject o=new JSONObject();o.put("name",c.getString(0));o.put("qty",c.getDouble(1));o.put("price",c.getDouble(2));o.put("total",c.getDouble(3));lines.put(o);}
        }
        out.put("lines",lines);return out;
    }

    public String partialReturn(long invoiceId,long itemId,double qty) {
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try{
            String kind;long partyId;double invRemaining;double lineQty,returned,price,cost;
            try(Cursor c=db.rawQuery("SELECT kind,COALESCE(party_id,0),remaining FROM invoices WHERE id=?",new String[]{String.valueOf(invoiceId)})){
                if(!c.moveToFirst()) throw new IllegalArgumentException("الفاتورة غير موجودة");
                kind=c.getString(0);partyId=c.getLong(1);invRemaining=c.getDouble(2);
            }
            try(Cursor c=db.rawQuery("SELECT qty,returned_qty,price,cost FROM invoice_lines WHERE invoice_id=? AND item_id=?",new String[]{String.valueOf(invoiceId),String.valueOf(itemId)})){
                if(!c.moveToFirst()) throw new IllegalArgumentException("سطر الفاتورة غير موجود");
                lineQty=c.getDouble(0);returned=c.getDouble(1);price=c.getDouble(2);cost=c.getDouble(3);
            }
            if(qty<=0||qty>lineQty-returned)throw new IllegalArgumentException("كمية المرتجع غير صحيحة");
            double amount=qty*price;double costAmount=qty*cost;double reduce=Math.min(invRemaining,amount);double refund=Math.max(0,amount-reduce);
            String rno="R-"+new SimpleDateFormat("yyyyMMddHHmmss",Locale.US).format(new Date());
            ContentValues rv=new ContentValues();rv.put("return_no",rno);rv.put("invoice_id",invoiceId);rv.put("item_id",itemId);rv.put("qty",qty);rv.put("amount",amount);rv.put("cost_amount",costAmount);db.insertOrThrow("returns",null,rv);
            db.execSQL("UPDATE invoice_lines SET returned_qty=returned_qty+? WHERE invoice_id=? AND item_id=?",new Object[]{qty,invoiceId,itemId});
            db.execSQL("UPDATE items SET qty=qty+? WHERE id=?",new Object[]{kind.equals("بيع")?qty:-qty,itemId});
            if(partyId>0 && reduce>0)db.execSQL("UPDATE parties SET balance=balance+? WHERE id=?",new Object[]{kind.equals("بيع")?-reduce:reduce,partyId});
            if(refund>0){
                ContentValues cv=new ContentValues();cv.put("kind",kind.equals("بيع")?"صرف":"قبض");cv.put("amount",refund);if(partyId>0)cv.put("party_id",partyId);cv.put("note","مرتجع جزئي");cv.put("ref_no",rno);db.insert("cash",null,cv);
            }
            db.execSQL("UPDATE invoices SET total=total-?,paid=paid-?,remaining=remaining-? WHERE id=?",new Object[]{amount,refund,reduce,invoiceId});
            db.setTransactionSuccessful();return rno;
        } finally {db.endTransaction();}
    }

    public JSONArray invoices() throws JSONException {
        JSONArray a=new JSONArray();SQLiteDatabase db=getReadableDatabase();
        try(Cursor c=db.rawQuery("""SELECT i.id,i.kind,i.invoice_no,COALESCE(p.name,'نقدي'),i.total,i.paid,i.remaining,i.created_at
                                   FROM invoices i LEFT JOIN parties p ON p.id=i.party_id ORDER BY i.id DESC""",null)){
            while(c.moveToNext()){JSONObject o=new JSONObject();o.put("id",c.getLong(0));o.put("kind",c.getString(1));o.put("no",c.getString(2));o.put("party",c.getString(3));o.put("total",c.getDouble(4));o.put("paid",c.getDouble(5));o.put("remaining",c.getDouble(6));o.put("date",c.getString(7));a.put(o);}
        }return a;
    }

    public JSONArray statement(long partyId) throws JSONException {
        JSONArray a=new JSONArray();SQLiteDatabase db=getReadableDatabase();
        double running=0;
        try(Cursor c=db.rawQuery("SELECT kind,invoice_no,remaining,created_at FROM invoices WHERE party_id=? ORDER BY created_at,id",new String[]{String.valueOf(partyId)})){
            while(c.moveToNext()){double move=c.getString(0).equals("بيع")?c.getDouble(2):-c.getDouble(2);running+=move;JSONObject o=new JSONObject();o.put("date",c.getString(3));o.put("ref",c.getString(1));o.put("move",move);o.put("balance",running);a.put(o);}
        }return a;
    }

    public JSONArray cashRows() throws JSONException {
        JSONArray a=new JSONArray();SQLiteDatabase db=getReadableDatabase();
        try(Cursor c=db.rawQuery("SELECT kind,amount,note,ref_no,created_at FROM cash ORDER BY id DESC",null)){
            while(c.moveToNext()){JSONObject o=new JSONObject();o.put("kind",c.getString(0));o.put("amount",c.getDouble(1));o.put("note",c.getString(2));o.put("ref",c.getString(3));o.put("date",c.getString(4));a.put(o);}
        }return a;
    }

    public double grossProfit() {
        SQLiteDatabase db=getReadableDatabase();
        try(Cursor c=db.rawQuery("""SELECT COALESCE(SUM((l.price-l.cost)*(l.qty-l.returned_qty)),0)
                                   FROM invoice_lines l JOIN invoices i ON i.id=l.invoice_id WHERE i.kind='بيع'""",null)){
            return c.moveToFirst()?c.getDouble(0):0;
        }
    }

    public boolean integrityCheck() {
        SQLiteDatabase db=getReadableDatabase();
        try(Cursor c=db.rawQuery("PRAGMA integrity_check",null)){return c.moveToFirst() && "ok".equalsIgnoreCase(c.getString(0));}
    }

    public String createBackup(File targetDir) throws IOException {
        getWritableDatabase().close();
        File dbFile=context.getDatabasePath(DB_NAME);if(!targetDir.exists())targetDir.mkdirs();
        String stamp=new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date());
        File out=new File(targetDir,"albayan_backup_"+stamp+".db");copyFile(dbFile,out);return out.getAbsolutePath();
    }

    public void restoreBackup(File backupFile) throws IOException {
        if(!backupFile.exists())throw new FileNotFoundException("ملف النسخة غير موجود");
        SQLiteDatabase test=null;
        try{
            test=SQLiteDatabase.openDatabase(backupFile.getAbsolutePath(),null,SQLiteDatabase.OPEN_READONLY);
            try(Cursor c=test.rawQuery("PRAGMA integrity_check",null)){if(!c.moveToFirst()||!"ok".equalsIgnoreCase(c.getString(0)))throw new IOException("النسخة غير سليمة");}
        }finally{if(test!=null)test.close();}
        close();File dbFile=context.getDatabasePath(DB_NAME);File safety=new File(dbFile.getParentFile(),"pre_restore_safety.db");if(dbFile.exists())copyFile(dbFile,safety);copyFile(backupFile,dbFile);getWritableDatabase();
    }

    public String schemaVersion() {
        SQLiteDatabase db=getReadableDatabase();
        try(Cursor c=db.rawQuery("SELECT v FROM meta WHERE k='schema_version'",null)){return c.moveToFirst()?c.getString(0):"غير معروف";}catch(Exception e){return "قديم";}
    }
    public int countRows(String table) {
        SQLiteDatabase db=getReadableDatabase();try(Cursor c=db.rawQuery("SELECT COUNT(*) FROM "+table,null)){return c.moveToFirst()?c.getInt(0):0;}
    }
    public double totalSales() {
        SQLiteDatabase db=getReadableDatabase();try(Cursor c=db.rawQuery("SELECT COALESCE(SUM(total),0) FROM invoices WHERE kind='بيع'",null)){return c.moveToFirst()?c.getDouble(0):0;}
    }
    public double totalPurchases() {
        SQLiteDatabase db=getReadableDatabase();try(Cursor c=db.rawQuery("SELECT COALESCE(SUM(total),0) FROM invoices WHERE kind='شراء'",null)){return c.moveToFirst()?c.getDouble(0):0;}
    }
    public double cashBalance() {
        SQLiteDatabase db=getReadableDatabase();try(Cursor c=db.rawQuery("SELECT COALESCE(SUM(CASE WHEN kind='قبض' THEN amount ELSE -amount END),0) FROM cash",null)){return c.moveToFirst()?c.getDouble(0):0;}
    }
    private static void copyFile(File src,File dst)throws IOException{
        try(InputStream in=new FileInputStream(src);OutputStream out=new FileOutputStream(dst)){byte[]buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);out.flush();}
    }
}
