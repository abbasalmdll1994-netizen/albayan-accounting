
package com.albayan.app;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import android.graphics.pdf.PdfDocument;
import android.graphics.*;
import androidx.core.content.FileProvider;
import java.io.*;
import java.util.*;
import org.json.*;

public class MainActivity extends Activity {
    private DatabaseHelper db;
    private TextView status;
    private static final int PICK_BACKUP=7001;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);setContentView(R.layout.activity_main);
        db=new DatabaseHelper(this);db.getWritableDatabase();status=findViewById(R.id.statusText);refreshStatus();
        findViewById(R.id.btnDashboard).setOnClickListener(v->dashboard());
        findViewById(R.id.btnItems).setOnClickListener(v->items());
        findViewById(R.id.btnParties).setOnClickListener(v->parties());
        findViewById(R.id.btnSales).setOnClickListener(v->invoice("بيع"));
        findViewById(R.id.btnPurchases).setOnClickListener(v->invoice("شراء"));
        findViewById(R.id.btnCash).setOnClickListener(v->cash());
        findViewById(R.id.btnStatement).setOnClickListener(v->statement());
        findViewById(R.id.btnReturns).setOnClickListener(v->returns());
        findViewById(R.id.btnReports).setOnClickListener(v->reports());
        findViewById(R.id.btnBackup).setOnClickListener(v->backup());
        findViewById(R.id.btnRestore).setOnClickListener(v->pickRestore());
        findViewById(R.id.btnHealth).setOnClickListener(v->health());
    }

    private EditText input(String hint){EditText e=new EditText(this);e.setHint(hint);return e;}
    private LinearLayout form(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(24,8,24,8);l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);return l;}
    private void refreshStatus(){status.setText("Android v6 | قاعدة البيانات: "+db.schemaVersion());}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}

    private void dashboard(){
        String msg=String.format(Locale.US,"المبيعات: %.2f\nالمشتريات: %.2f\nمجمل الربح: %.2f\nرصيد الصندوق: %.2f\nالأصناف: %d\nالأطراف: %d",
                db.totalSales(),db.totalPurchases(),db.grossProfit(),db.cashBalance(),db.countRows("items"),db.countRows("parties"));
        new AlertDialog.Builder(this).setTitle("الرئيسية").setMessage(msg).setPositiveButton("حسناً",null).show();
    }

    private void items(){
        try{
            LinearLayout l=form();EditText code=input("الكود");EditText bar=input("الباركود");EditText name=input("اسم الصنف");EditText unit=input("الوحدة");EditText cost=input("التكلفة");EditText price=input("سعر البيع");EditText min=input("الحد الأدنى");
            for(View v:new View[]{code,bar,name,unit,cost,price,min})l.addView(v);
            JSONArray a=db.items();TextView list=new TextView(this);StringBuilder s=new StringBuilder("\nالأصناف الحالية:\n");
            for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);s.append(o.getString("code")).append(" | ").append(o.getString("name")).append(" | كمية ").append(o.getDouble("qty")).append("\n");}
            list.setText(s.toString());l.addView(list);
            new AlertDialog.Builder(this).setTitle("الأصناف والمخزون").setView(l).setPositiveButton("إضافة",(d,w)->{
                try{db.addItem(code.getText().toString(),bar.getText().toString(),name.getText().toString(),"",unit.getText().toString(),num(cost),num(price),num(min));toast("تمت إضافة الصنف");}catch(Exception e){toast(e.getMessage());}
            }).setNegativeButton("إغلاق",null).show();
        }catch(Exception e){toast(e.getMessage());}
    }

    private void parties(){
        LinearLayout l=form();Spinner kind=new Spinner(this);kind.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"زبون","مورد"}));
        EditText code=input("الكود");EditText name=input("الاسم");EditText phone=input("الهاتف");EditText address=input("العنوان");
        l.addView(kind);for(View v:new View[]{code,name,phone,address})l.addView(v);
        try{
            JSONArray a=db.parties(null);TextView list=new TextView(this);StringBuilder s=new StringBuilder("\nالزبائن والموردون:\n");
            for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);s.append(o.getString("kind")).append(" | ").append(o.getString("name")).append(" | رصيد ").append(o.getDouble("balance")).append("\n");}
            list.setText(s.toString());l.addView(list);
        }catch(Exception ignored){}
        new AlertDialog.Builder(this).setTitle("الزبائن والموردون").setView(l).setPositiveButton("إضافة",(d,w)->{
            try{db.addParty(kind.getSelectedItem().toString(),code.getText().toString(),name.getText().toString(),phone.getText().toString(),address.getText().toString());toast("تمت الإضافة");}catch(Exception e){toast(e.getMessage());}
        }).setNegativeButton("إغلاق",null).show();
    }



    private void invoice(String kind){
        try{
            final JSONArray its=db.items();
            final JSONArray ps=db.parties(kind.equals("بيع")?"زبون":"مورد");
            if(its.length()==0){toast("أضف صنفاً أولاً");return;}

            final ArrayList<JSONObject> cart=new ArrayList<>();
            final LinearLayout root=form();

            final Spinner party=new Spinner(this);
            final List<String> pnames=new ArrayList<>();pnames.add("نقدي");
            for(int i=0;i<ps.length();i++)pnames.add(ps.getJSONObject(i).getString("name"));
            party.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,pnames));
            root.addView(party);

            final TextView cartView=new TextView(this);cartView.setPadding(0,14,0,14);root.addView(cartView);
            Button addLine=new Button(this);addLine.setText("إضافة صنف");root.addView(addLine);
            Button editLine=new Button(this);editLine.setText("تعديل سطر");root.addView(editLine);
            Button deleteLine=new Button(this);deleteLine.setText("حذف سطر");root.addView(deleteLine);
            final EditText discount=input("الخصم");root.addView(discount);
            final EditText paid=input("المدفوع");root.addView(paid);

            final Runnable refreshCart=()->{
                StringBuilder s=new StringBuilder("تفاصيل الفاتورة:\n");double gross=0;
                try{
                    for(int i=0;i<cart.size();i++){
                        JSONObject o=cart.get(i);double lt=o.getDouble("qty")*o.getDouble("price");gross+=lt;
                        s.append(i+1).append(") ").append(o.getString("name")).append(" | ").append(o.getDouble("qty")).append(" × ").append(o.getDouble("price")).append(" = ").append(lt).append("\n");
                    }
                    double disc=discount.getText().toString().trim().isEmpty()?0:Double.parseDouble(discount.getText().toString().trim());
                    s.append("\nالإجمالي قبل الخصم: ").append(gross).append("\nالخصم: ").append(disc).append("\nالصافي: ").append(Math.max(0,gross-disc));
                }catch(Exception ignored){}
                cartView.setText(s.toString());
            };
            refreshCart.run();

            addLine.setOnClickListener(v->showLineEditor(kind,its,null,obj->{cart.add(obj);refreshCart.run();}));

            editLine.setOnClickListener(v->{
                if(cart.isEmpty()){toast("لا توجد سطور");return;}
                String[] labels=new String[cart.size()];
                try{for(int i=0;i<cart.size();i++)labels[i]=(i+1)+" - "+cart.get(i).getString("name");}catch(Exception ignored){}
                new AlertDialog.Builder(this).setTitle("اختر السطر").setItems(labels,(d,which)->
                    showLineEditor(kind,its,cart.get(which),obj->{cart.set(which,obj);refreshCart.run();})
                ).show();
            });

            deleteLine.setOnClickListener(v->{
                if(cart.isEmpty()){toast("لا توجد سطور");return;}
                String[] labels=new String[cart.size()];
                try{for(int i=0;i<cart.size();i++)labels[i]=(i+1)+" - "+cart.get(i).getString("name");}catch(Exception ignored){}
                new AlertDialog.Builder(this).setTitle("حذف أي سطر").setItems(labels,(d,which)->{cart.remove(which);refreshCart.run();}).show();
            });

            AlertDialog dlg=new AlertDialog.Builder(this).setTitle("فاتورة "+kind).setView(root).setPositiveButton("حفظ",null).setNegativeButton("إلغاء",null).create();
            dlg.setOnShowListener(x->dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
                try{
                    if(cart.isEmpty()){toast("أضف صنفاً واحداً على الأقل");return;}
                    JSONArray lines=new JSONArray();for(JSONObject o:cart)lines.put(o);
                    long partyId=0;if(party.getSelectedItemPosition()>0)partyId=ps.getJSONObject(party.getSelectedItemPosition()-1).getLong("id");
                    long iid=db.saveInvoiceMulti(kind,partyId,lines,num(paid),num(discount));
                    toast("تم حفظ الفاتورة");dlg.dismiss();askSharePdf(iid);
                }catch(Exception e){toast(e.getMessage());}
            }));
            dlg.show();
        }catch(Exception e){toast(e.getMessage());}
    }

    interface LineCallback { void done(JSONObject obj); }

    private void showLineEditor(String kind,JSONArray its,JSONObject existing,LineCallback cb){
        try{
            LinearLayout f=form();Spinner item=new Spinner(this);List<String> names=new ArrayList<>();
            for(int i=0;i<its.length();i++)names.add(its.getJSONObject(i).getString("name"));
            item.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,names));
            EditText qty=input("الكمية");EditText price=input("السعر");

            if(existing!=null){
                long oldId=existing.getLong("item_id");
                for(int i=0;i<its.length();i++)if(its.getJSONObject(i).getLong("id")==oldId)item.setSelection(i);
                qty.setText(String.valueOf(existing.getDouble("qty")));
                price.setText(String.valueOf(existing.getDouble("price")));
            }

            f.addView(item);f.addView(qty);f.addView(price);
            new AlertDialog.Builder(this).setTitle(existing==null?"إضافة سطر":"تعديل السطر").setView(f)
            .setPositiveButton("حفظ",(d,w)->{
                try{
                    JSONObject it=its.getJSONObject(item.getSelectedItemPosition());
                    double q=num(qty);if(q<=0)throw new IllegalArgumentException("كمية غير صحيحة");
                    double pr=price.getText().toString().trim().isEmpty()?(kind.equals("بيع")?it.getDouble("price"):it.getDouble("cost")):num(price);
                    JSONObject ln=new JSONObject();
                    ln.put("item_id",it.getLong("id"));ln.put("name",it.getString("name"));ln.put("qty",q);ln.put("price",pr);
                    cb.done(ln);
                }catch(Exception e){toast(e.getMessage());}
            }).setNegativeButton("إلغاء",null).show();
        }catch(Exception e){toast(e.getMessage());}
    }

    private void askSharePdf(long invoiceId){
        new AlertDialog.Builder(this).setTitle("الفاتورة محفوظة").setMessage("هل تريد إنشاء ومشاركة PDF للفاتورة؟")
        .setPositiveButton("مشاركة PDF",(d,w)->{
            try{sharePdf(createInvoicePdf(invoiceId));}catch(Exception e){toast("تعذر إنشاء PDF: "+e.getMessage());}
        }).setNegativeButton("لاحقاً",null).show();
    }

    private File createInvoicePdf(long invoiceId) throws Exception{
        JSONObject inv=db.invoiceDetails(invoiceId);
        JSONArray lines=inv.getJSONArray("lines");
        PdfDocument doc=new PdfDocument();
        PdfDocument.PageInfo info=new PdfDocument.PageInfo.Builder(595,842,1).create();
        PdfDocument.Page page=doc.startPage(info);
        Canvas c=page.getCanvas();Paint p=new Paint();p.setAntiAlias(true);p.setTextAlign(Paint.Align.RIGHT);
        float x=555,y=50;

        p.setTextSize(24);c.drawText("برنامج البيان",x,y,p);y+=35;
        p.setTextSize(16);c.drawText("فاتورة "+inv.getString("kind")+" - "+inv.getString("no"),x,y,p);y+=25;
        c.drawText("الطرف: "+inv.getString("party"),x,y,p);y+=25;
        c.drawText("التاريخ: "+inv.getString("date"),x,y,p);y+=35;

        p.setTextSize(14);
        for(int i=0;i<lines.length() && y<720;i++){
            JSONObject ln=lines.getJSONObject(i);
            c.drawText((i+1)+") "+ln.getString("name")+"   "+ln.getDouble("qty")+" × "+ln.getDouble("price")+" = "+ln.getDouble("total"),x,y,p);
            y+=23;
        }

        y+=20;c.drawText("الخصم: "+inv.getDouble("discount"),x,y,p);y+=25;
        c.drawText("الصافي: "+inv.getDouble("total"),x,y,p);y+=25;
        c.drawText("المدفوع: "+inv.getDouble("paid"),x,y,p);y+=25;
        c.drawText("المتبقي: "+inv.getDouble("remaining"),x,y,p);

        doc.finishPage(page);
        File out=new File(getCacheDir(),"invoice_"+inv.getString("no")+".pdf");
        try(FileOutputStream fos=new FileOutputStream(out)){doc.writeTo(fos);}finally{doc.close();}
        return out;
    }

    private void sharePdf(File f){
        Uri uri=FileProvider.getUriForFile(this,getPackageName()+".fileprovider",f);
        Intent s=new Intent(Intent.ACTION_SEND);
        s.setType("application/pdf");
        s.putExtra(Intent.EXTRA_STREAM,uri);
        s.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(s,"مشاركة الفاتورة"));
    }

    private void cash(){
        try{
            JSONArray a=db.cashRows();StringBuilder s=new StringBuilder("رصيد الصندوق: ").append(db.cashBalance()).append("\n\n");
            for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);s.append(o.getString("date")).append(" | ").append(o.getString("kind")).append(" | ").append(o.getDouble("amount")).append(" | ").append(o.optString("ref","")).append("\n");}
            new AlertDialog.Builder(this).setTitle("الصندوق").setMessage(s.toString()).setPositiveButton("حسناً",null).show();
        }catch(Exception e){toast(e.getMessage());}
    }

    private void statement(){
        try{
            JSONArray ps=db.parties(null);if(ps.length()==0){toast("لا يوجد زبائن أو موردون");return;}
            List<String> names=new ArrayList<>();for(int i=0;i<ps.length();i++)names.add(ps.getJSONObject(i).getString("name"));
            new AlertDialog.Builder(this).setTitle("اختر الحساب").setItems(names.toArray(new String[0]),(d,which)->{
                try{
                    JSONObject p=ps.getJSONObject(which);JSONArray a=db.statement(p.getLong("id"));StringBuilder s=new StringBuilder();
                    for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);s.append(o.getString("date")).append(" | ").append(o.getString("ref")).append(" | حركة ").append(o.getDouble("move")).append(" | رصيد ").append(o.getDouble("balance")).append("\n");}
                    new AlertDialog.Builder(this).setTitle("كشف حساب - "+p.getString("name")).setMessage(s.length()==0?"لا توجد حركات":s.toString()).setPositiveButton("حسناً",null).show();
                }catch(Exception e){toast(e.getMessage());}
            }).show();
        }catch(Exception e){toast(e.getMessage());}
    }

    private void returns(){
        try{
            JSONArray invs=db.invoices();JSONArray its=db.items();if(invs.length()==0||its.length()==0){toast("لا توجد بيانات مرتجعات");return;}
            List<String> invNames=new ArrayList<>();for(int i=0;i<invs.length();i++){JSONObject o=invs.getJSONObject(i);invNames.add(o.getString("kind")+" | "+o.getString("no")+" | "+o.getString("party"));}
            List<String> itemNames=new ArrayList<>();for(int i=0;i<its.length();i++)itemNames.add(its.getJSONObject(i).getString("name"));
            LinearLayout l=form();Spinner inv=new Spinner(this);inv.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,invNames));Spinner item=new Spinner(this);item.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,itemNames));EditText qty=input("كمية المرتجع");l.addView(inv);l.addView(item);l.addView(qty);
            new AlertDialog.Builder(this).setTitle("مرتجع جزئي").setView(l).setPositiveButton("تنفيذ",(d,w)->{
                try{String no=db.partialReturn(invs.getJSONObject(inv.getSelectedItemPosition()).getLong("id"),its.getJSONObject(item.getSelectedItemPosition()).getLong("id"),num(qty));toast("تم المرتجع: "+no);}catch(Exception e){toast(e.getMessage());}
            }).setNegativeButton("إلغاء",null).show();
        }catch(Exception e){toast(e.getMessage());}
    }

    private void reports(){
        String msg=String.format(Locale.US,"إجمالي المبيعات: %.2f\nإجمالي المشتريات: %.2f\nمجمل الربح: %.2f\nرصيد الصندوق: %.2f\nعدد الأصناف: %d\nعدد الفواتير: %d",
                db.totalSales(),db.totalPurchases(),db.grossProfit(),db.cashBalance(),db.countRows("items"),db.countRows("invoices"));
        new AlertDialog.Builder(this).setTitle("التقارير").setMessage(msg).setPositiveButton("حسناً",null).show();
    }

    private double num(EditText e){String s=e.getText().toString().trim();return s.isEmpty()?0:Double.parseDouble(s);}
    private void backup(){try{File dir=new File(getExternalFilesDir(null),"Backups");toast("تم إنشاء النسخة:\n"+db.createBackup(dir));}catch(Exception e){toast(e.getMessage());}}
    private void pickRestore(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK_BACKUP);}
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(req==PICK_BACKUP&&res==RESULT_OK&&data!=null){try{Uri uri=data.getData();File tmp=new File(getCacheDir(),"restore_candidate.db");try(InputStream in=getContentResolver().openInputStream(uri);OutputStream out=new FileOutputStream(tmp)){byte[]b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);}db.restoreBackup(tmp);refreshStatus();toast("تم الاسترجاع");}catch(Exception e){toast(e.getMessage());}}}
    private void health(){new AlertDialog.Builder(this).setTitle("فحص قاعدة البيانات").setMessage((db.integrityCheck()?"قاعدة البيانات سليمة ✅":"يوجد خلل ⚠️")+"\nالإصدار: "+db.schemaVersion()).setPositiveButton("حسناً",null).show();}
}
